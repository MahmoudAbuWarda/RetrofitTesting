package com.example.retrofittesting

data class MyContacts(
    val contacts: List<Contact>
)