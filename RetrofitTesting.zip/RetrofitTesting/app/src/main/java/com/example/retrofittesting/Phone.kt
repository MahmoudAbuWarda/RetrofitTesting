package com.example.retrofittesting

data class Phone(
    val home: String,
    val mobile: String,
    val office: String
)